"""Federated Averaging (FedAvg) simulation. Clients run in one process;
only parameter vectors cross the client/server boundary."""
import numpy as np
from models.traffic_model import LinearModel
from utils.metrics import mae, rmse
from utils.communication import params_bytes

SCALE = 100.0

def run_federated(clients, test, rounds, local_epochs=2, lr=0.1, on_round=None):
    """clients: {name: (X, y)} local data. test: {name: (X, y)}. Returns (model, history)."""
    glob = LinearModel()
    history, cumulative = [], 0
    n_total = sum(len(v[1]) for v in clients.values())
    for r in range(1, rounds + 1):
        updates, sizes, download, upload = [], [], 0, 0
        for i, (name, (X, y)) in enumerate(clients.items()):
            download += params_bytes(glob.get_params())      # server -> client
            local = LinearModel(); local.set_params(glob.get_params())
            local.fit(X, y, epochs=local_epochs, lr=lr, seed=r * 100 + i)
            upd = local.get_params()                         # only parameters leave the client
            upload += params_bytes(upd)                      # client -> server
            updates.append(upd); sizes.append(len(y))
        glob.set_params(np.average(updates, axis=0, weights=sizes))   # FedAvg
        yt = np.concatenate([test[n][1] for n in clients])
        pt = np.concatenate([glob.predict(test[n][0]) for n in clients])
        cumulative += upload + download
        history.append(dict(
            round=r, mae=mae(yt * SCALE, pt * SCALE), rmse=rmse(yt * SCALE, pt * SCALE),
            upload=upload, download=download, total=upload + download,
            cumulative=cumulative, per_client=(upload + download) / len(clients),
            client_mae={n: mae(test[n][1] * SCALE, glob.predict(test[n][0]) * SCALE) for n in clients},
            client_share={n: len(clients[n][1]) / n_total for n in clients}))
        if on_round:
            on_round(history[-1])
    return glob, history
