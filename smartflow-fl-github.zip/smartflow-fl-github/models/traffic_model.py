"""Feature engineering + models.
LinearModel is used for BOTH centralized and federated runs so the comparison is fair
(linear parameters can be averaged with FedAvg; random forests cannot).
RandomForest is trained centrally for the Traffic Prediction page."""
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor

SCALE = 100.0  # fixed scaling constant (no data statistics need to be shared)
FEATURES = ["h_sin1", "h_cos1", "h_sin2", "h_cos2", "d_sin", "d_cos",
            "prev_count", "prev_speed", "prev_occ"]

def prepare(df):
    """Features: time of the period to predict + previous period's readings."""
    df = df.copy()
    df["timestamp"] = pd.to_datetime(df["timestamp"])
    df = df.sort_values(["junction_id", "timestamp"])
    g = df.groupby("junction_id")
    df["prev_count"] = g["vehicle_count"].shift(1) / SCALE
    df["prev_speed"] = g["average_speed"].shift(1) / SCALE
    df["prev_occ"] = g["occupancy"].shift(1) / SCALE
    df = df.dropna().copy()
    a = 2 * np.pi * df["hour"] / 24
    df["h_sin1"], df["h_cos1"] = np.sin(a), np.cos(a)
    df["h_sin2"], df["h_cos2"] = np.sin(2 * a), np.cos(2 * a)
    b = 2 * np.pi * df["day_of_week"] / 7
    df["d_sin"], df["d_cos"] = np.sin(b), np.cos(b)
    df["y"] = df["vehicle_count"] / SCALE
    return df

def split_by_junction(df, test_frac=0.2):
    """Time-based split inside each junction (last 20% = test)."""
    tr, te = [], []
    for _, d in df.groupby("junction_id"):
        k = int(len(d) * (1 - test_frac))
        tr.append(d.iloc[:k]); te.append(d.iloc[k:])
    return pd.concat(tr), pd.concat(te)

def xy(d):
    return d[FEATURES].to_numpy(np.float64), d["y"].to_numpy(np.float64)

class LinearModel:
    """Linear regression trained with mini-batch SGD. params = [weights..., bias]."""
    def __init__(self, n_features=len(FEATURES)):
        self.w = np.zeros(n_features + 1)

    def get_params(self):
        return self.w.copy()

    def set_params(self, w):
        self.w = np.asarray(w, dtype=np.float64).copy()

    def predict(self, X):  # scaled output
        return X @ self.w[:-1] + self.w[-1]

    def fit(self, X, y, epochs=2, lr=0.1, batch=32, seed=0):
        rng = np.random.default_rng(seed)
        for _ in range(epochs):
            idx = rng.permutation(len(X))
            for i in range(0, len(X), batch):
                b = idx[i:i + batch]
                err = self.predict(X[b]) - y[b]
                self.w[:-1] -= lr * (X[b].T @ err) / len(b)
                self.w[-1] -= lr * err.mean()

def train_forest(X, y):
    return RandomForestRegressor(n_estimators=100, max_depth=12, random_state=0, n_jobs=-1).fit(X, y)
