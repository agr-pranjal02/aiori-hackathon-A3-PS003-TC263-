"""Communication cost helpers. Sizes come from the real parameter arrays (float32)."""
import numpy as np

def params_bytes(params):
    """Bytes needed to transmit a parameter vector as float32."""
    return int(np.asarray(params, dtype=np.float32).nbytes)

def fmt_bytes(n):
    if n < 1024:
        return f"{n:.0f} B"
    for unit in ["KB", "MB", "GB"]:
        n /= 1024
        if n < 1024 or unit == "GB":
            return f"{n:.2f} {unit}"
