"""Synthetic traffic generator: 4 junctions, hourly records, rush-hour patterns."""
import numpy as np
import pandas as pd

REQUIRED = ["timestamp", "junction_id", "vehicle_count", "average_speed",
            "occupancy", "hour", "day_of_week"]
# Each junction has its own pattern (non-IID data)
PROFILES = {
    "Junction A": dict(base=25, morning=90, evening=60),   # commuter inbound
    "Junction B": dict(base=30, morning=55, evening=95),   # commuter outbound
    "Junction C": dict(base=40, morning=60, evening=65),   # city centre
    "Junction D": dict(base=15, morning=35, evening=40),   # quiet suburb
}

def _peak(h, centre, width):
    return np.exp(-((h - centre) ** 2) / (2 * width ** 2))

def generate_traffic_data(days=28, seed=42):
    rng = np.random.default_rng(seed)
    ts = pd.date_range("2024-01-01", periods=days * 24, freq="h")
    frames = []
    for jid, p in PROFILES.items():
        h = ts.hour.values.astype(float)
        scale = np.where(ts.dayofweek.values >= 5, 0.6, 1.0)  # quieter weekends
        count = (p["base"] * (0.3 + 0.7 * _peak(h, 13, 6))
                 + scale * p["morning"] * _peak(h, 8, 1.3)
                 + scale * p["evening"] * _peak(h, 17.5, 1.5))
        count = np.clip(count + rng.normal(0, 4, len(ts)), 1, None)
        occ = np.clip(count / 1.4 + rng.normal(0, 3, len(ts)), 1, 100)
        speed = np.clip(60 - 0.4 * count + rng.normal(0, 2.5, len(ts)), 5, 80)
        frames.append(pd.DataFrame({
            "timestamp": ts, "junction_id": jid,
            "vehicle_count": count.round().astype(int),
            "average_speed": speed.round(1), "occupancy": occ.round(1),
            "hour": ts.hour, "day_of_week": ts.dayofweek}))
    return pd.concat(frames, ignore_index=True)

if __name__ == "__main__":
    generate_traffic_data().to_csv("data/sample_traffic.csv", index=False)
    print("Saved data/sample_traffic.csv")
